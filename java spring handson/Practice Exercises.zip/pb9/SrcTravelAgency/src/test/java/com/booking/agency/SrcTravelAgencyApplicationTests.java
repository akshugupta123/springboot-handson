package com.booking.agency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrcTravelAgencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
