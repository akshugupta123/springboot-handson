INSERT INTO db.Book(bookTitle,bookPublisher,bookIsbn,bookNumberOfPages,bookYear) VALUES('Tinkle','comics',789-456-123,200,1998);

INSERT INTO db.Book(bookTitle,bookPublisher,bookIsbn,bookNumberOfPages,bookYear) VALUES('marvel','action',789-456-123,300,1999);

INSERT INTO db.Book(bookTitle,bookPublisher,bookIsbn,bookNumberOfPages,bookYear) VALUES('richdad','comics',789-456-123,400,2000);

INSERT INTO db.Book(bookTitle,bookPublisher,bookIsbn,bookNumberOfPages,bookYear) VALUES('poordad','comics',789-456-123,500,2001);